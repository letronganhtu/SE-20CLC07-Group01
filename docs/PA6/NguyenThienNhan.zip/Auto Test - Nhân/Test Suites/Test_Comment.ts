<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test_Comment</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>3565e838-694a-43a7-bb9d-e30261f503d7</testSuiteGuid>
   <testCaseLink>
      <guid>b4ed88c3-987f-4f26-aa67-9141c8331e3b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Comment - No content</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>90cebd74-90a8-4cee-b29f-93ba4941fdb9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Comment - Successfully</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>b04d009b-a5b5-4211-bb4a-09112b145193</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>b04d009b-a5b5-4211-bb4a-09112b145193</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Comment</value>
         <variableId>539b23df-1e0b-44fe-a3f0-508566f0eaf2</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
