<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Search test</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>cebe3e30-102e-40b2-baee-9007522bbb48</testSuiteGuid>
   <testCaseLink>
      <guid>1a16ffe4-821d-47fc-96f7-b982a231c04d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Search with blank key</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>dec6eb5f-dd59-4712-9600-6d1681c71a83</id>
         <iterationEntity>
            <iterationType>RANGE</iterationType>
            <value>1-1</value>
         </iterationEntity>
         <testDataId>Data Files/Data Testing</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>dec6eb5f-dd59-4712-9600-6d1681c71a83</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Key search</value>
         <variableId>b4479ca2-3c0f-453f-a332-fda47e5b89b0</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>6a4834af-abd7-4efb-a319-ded5070df056</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Search with invalid key</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>e9cf3672-82ef-4b7a-8a77-2ae3ee29b73e</id>
         <iterationEntity>
            <iterationType>RANGE</iterationType>
            <value>2-4</value>
         </iterationEntity>
         <testDataId>Data Files/Data Testing</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>e9cf3672-82ef-4b7a-8a77-2ae3ee29b73e</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Key search</value>
         <variableId>76cdabc1-3939-4219-97ee-f3848f4b5397</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
