<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Username                               _6fa21b</name>
   <tag></tag>
   <elementGuidId>9a7edaed-0fbe-4ecd-b416-32b7f3b927e5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='password'])[1]/following::div[5]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.container</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>9211ce52-0f5d-4588-9711-65d24e4c06f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>container</value>
      <webElementGuid>5bb13e24-5f3c-4652-9aae-50826db70574</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    Username *
                    
                    
                    Password *
                    Warning: Caps Lock is on
                    

                    
                        Password must contain the following:
                        A lowercase letter
                        A capital (uppercase) letter
                        A number
                        A special character
                        Minimum 6 characters
                    

                    Confirm Password *
                    
                    
                    
                        Full name *
                        
                    

                    
                </value>
      <webElementGuid>6494f248-5810-4776-9494-5e2c1e4ce532</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;sign-in-form&quot;]/form[@class=&quot;sign-up-form&quot;]/div[@class=&quot;container&quot;]</value>
      <webElementGuid>689afbe2-9811-4f4d-bf73-8c8ad5a02562</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='password'])[1]/following::div[5]</value>
      <webElementGuid>6d66d0f9-c9fb-4765-a703-ba68bd12dd5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div</value>
      <webElementGuid>cffd10ea-22df-44e2-b4b1-b2535b6c86fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                    Username *
                    
                    
                    Password *
                    Warning: Caps Lock is on
                    

                    
                        Password must contain the following:
                        A lowercase letter
                        A capital (uppercase) letter
                        A number
                        A special character
                        Minimum 6 characters
                    

                    Confirm Password *
                    
                    
                    
                        Full name *
                        
                    

                    
                ' or . = '
                    Username *
                    
                    
                    Password *
                    Warning: Caps Lock is on
                    

                    
                        Password must contain the following:
                        A lowercase letter
                        A capital (uppercase) letter
                        A number
                        A special character
                        Minimum 6 characters
                    

                    Confirm Password *
                    
                    
                    
                        Full name *
                        
                    

                    
                ')]</value>
      <webElementGuid>b8ec8b07-c67e-4ac1-b0c3-b2174542797a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
