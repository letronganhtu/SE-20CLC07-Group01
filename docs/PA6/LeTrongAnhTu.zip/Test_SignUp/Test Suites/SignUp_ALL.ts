<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>SignUp_ALL</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>5bd9983c-3729-496e-a3ca-eacc518cfa66</testSuiteGuid>
   <testCaseLink>
      <guid>27270777-d1e1-4279-a6bc-bb7ece5adba4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp_Successfully</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>8f6cfded-9a55-49ac-a943-3d48b688fb3c</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Data_SignUpSuccessfully</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>8f6cfded-9a55-49ac-a943-3d48b688fb3c</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Username</value>
         <variableId>1f109a61-4432-49dc-8de9-32efef67c942</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>8f6cfded-9a55-49ac-a943-3d48b688fb3c</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Password</value>
         <variableId>acc1038c-bf7b-45ff-ad2f-fab98c35a10d</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>8f6cfded-9a55-49ac-a943-3d48b688fb3c</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Confirm Password</value>
         <variableId>64019869-3f3d-4a69-8994-cdb00518cc84</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>8f6cfded-9a55-49ac-a943-3d48b688fb3c</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Full Name</value>
         <variableId>47097cd6-3785-4066-b285-6258b8c71924</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>70776bf4-5242-4b24-97e3-a0c41fb607b6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SignUp_InvalidConfirmPass</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>348fde45-730f-4bda-8353-42a7d5ed7632</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Data_InvalidPass</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>348fde45-730f-4bda-8353-42a7d5ed7632</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Username</value>
         <variableId>bd7ce992-0ec8-4dd6-a0ae-f7cd4fdae437</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>348fde45-730f-4bda-8353-42a7d5ed7632</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Password</value>
         <variableId>bec36a97-b765-4fb7-b677-3a2007b27b36</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>348fde45-730f-4bda-8353-42a7d5ed7632</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Confirm Password</value>
         <variableId>d1f684a3-ba31-4601-96ee-99a737b08475</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>348fde45-730f-4bda-8353-42a7d5ed7632</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Full Name</value>
         <variableId>13c9c8eb-e3f6-47f1-83cd-6b057708de56</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
