1. Update Section 5 + 6
2. Add <<include>> and <<extend>> relationship to the Use-Case model
3. Remove Database component (4.12) in Logical View
4. Latest version of this document is 1.3
