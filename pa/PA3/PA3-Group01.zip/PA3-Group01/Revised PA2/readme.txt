1. We have updated the Use-case model (delete <<include>> and <<extend>>)
2. We have updated the Use-case Post recipe and List of my posts in Use-case Specifications
3. We also reviewed all the other Use-case specifications and edited them with more details and accuracy.
4. Latest version of the file: 1.2